
class InvalidAgeException
{
public:
	InvalidAgeException() {};
};

class InvalidCapacityException
{
public:
	InvalidCapacityException(){};
};

class InvalidTimeLimitException
{
public:
	InvalidTimeLimitException(){};
};

class InvalidNumberPeopleException
{
public:
	InvalidNumberPeopleException(){};
};


